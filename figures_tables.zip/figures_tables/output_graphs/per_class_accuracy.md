| class | samples | accuracy | accuracy_percent |
| --- | --- | --- | --- |
| .ipynb_checkpoints | 0 | nan | nan |
| incorrect_mask | 690 | 0.9260869565217391 | 92.6086956521739 |
| with_mask | 690 | 0.0014492753623188406 | 0.14492753623188406 |
| without_mask | 686 | 0.9752186588921283 | 97.52186588921283 |