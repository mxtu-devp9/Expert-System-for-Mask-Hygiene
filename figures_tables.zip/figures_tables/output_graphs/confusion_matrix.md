| index | pred_incorrect_mask | pred_with_mask | pred_without_mask |
| --- | --- | --- | --- |
| true_incorrect_mask | 639 | 8 | 43 |
| true_with_mask | 689 | 1 | 0 |
| true_without_mask | 2 | 15 | 669 |