| class | samples | accuracy | accuracy_percent |
| --- | --- | --- | --- |
| .ipynb_checkpoints | 0 | nan | nan |
| incorrect_mask | 690 | 0.782608695652174 | 78.26086956521739 |
| with_mask | 690 | 0.9985507246376811 | 99.85507246376811 |
| without_mask | 686 | 0.9956268221574344 | 99.56268221574344 |