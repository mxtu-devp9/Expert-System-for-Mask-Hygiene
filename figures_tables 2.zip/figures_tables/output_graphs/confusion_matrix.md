| index | pred_incorrect_mask | pred_with_mask | pred_without_mask |
| --- | --- | --- | --- |
| true_incorrect_mask | 540 | 134 | 16 |
| true_with_mask | 1 | 689 | 0 |
| true_without_mask | 3 | 0 | 683 |